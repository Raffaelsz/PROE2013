# PES 2013 Android — v1.5 DEV

Esta é uma base experimental Android. A v1.5 melhora a leitura estrutural inicial do cabeçalho XEX2, valida limites de leitura e produz um relatório compartilhável sem carregar o arquivo inteiro na memória.

## Estado real
- Interface Android e seleção de arquivo: presentes.
- Leitura preliminar de cabeçalho XEX2: presente.
- Descriptografia/descompressão de imagem XEX: não implementada.
- Interpretador PowerPC/Xbox 360: não implementado.
- APIs do sistema Xbox 360 e renderização do jogo: não implementadas.
- Execução nativa do PES 2013: não disponível nesta versão.

Um arquivo chamado `default.XEX` costuma ser o executável de entrada, mas o nome e a assinatura não provam, sozinhos, que o conteúdo está completo ou que pode ser executado. A análise estrutural é apenas um passo inicial; não converte o jogo em APK.

## Compilar
Abra o projeto no Android Studio ou envie o conteúdo ao repositório GitHub e execute o workflow de Android Actions. A compilação desta edição não foi executada neste ambiente; valide o resultado no CI antes de instalar.
