package com.santos.pes2013launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val lime = Color.rgb(166, 255, 0)
    private val bg = Color.rgb(12, 14, 13)
    private val panel = Color.rgb(27, 31, 28)
    private var isoUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var settings: LinearLayout
    private lateinit var controls: LinearLayout
    private val prefs by lazy { getSharedPreferences("pes_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 18, 18, 18) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("PES 2013", 30, lime, true))
        content.addView(label("NATIVE PORT LAB  •  v1.4 DEV", 12, Color.LTGRAY, true))
        content.addView(label("Desempenho primeiro | Desenvolvedor: @raffael.sz", 13, Color.WHITE, false))
        content.addView(label("GitHub  •  Projeto comunitário não oficial", 12, lime, false))

        val pick = button("📂  SELECIONAR ISO / JOGO") { chooseGame() }
        content.addView(pick)
        status = label("Nenhum jogo selecionado", 13, Color.LTGRAY, false)
        content.addView(status)
        content.addView(button("▶  JOGAR / ABRIR NO X360 MOBILE") { launchGame() })
        content.addView(button("🔎  ANALISAR ARQUIVO / GERAR DIAGNÓSTICO") { analyzeSelectedFile() })
        content.addView(button("🧩  ANALISAR CABEÇALHO XEX2") { analyzeXexHeader() })
        content.addView(label("MOTOR NATIVO: NÃO IMPLEMENTADO — esta versão analisa metadados do arquivo; não executa o PES 2013 nativamente.", 12, Color.YELLOW, true))
        content.addView(button("⚙  CONFIGURAÇÕES GRÁFICAS") { settings.visibility = if (settings.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        settings = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(12, 8, 12, 8); setBackgroundColor(panel) }
        content.addView(settings)
        addSpinner(settings, "Perfil", listOf("Desempenho", "Equilibrado", "Qualidade gráfica"), "profile")
        addSpinner(settings, "Renderizador (preferência; depende do emulador)", listOf("Automático", "Vulkan", "OpenGL"), "renderer")
        addSpinner(settings, "Resolução interna (preferência)", listOf("50%", "75%", "100%"), "resolution")
        addSpinner(settings, "Limite de FPS (preferência)", listOf("30 FPS", "60 FPS", "Sem limite"), "fps")
        addSpinner(settings, "Texturas (preferência)", listOf("Baixa", "Média", "Alta"), "textures")
        addSpinner(settings, "Tamanho da tela", listOf("Ajustar à tela", "16:9", "4:3"), "screen")
        settings.addView(label("Estas preferências ficam salvas no launcher. Elas só alteram o jogo se o emulador aceitar uma integração específica; ainda não aplicam opções gráficas diretamente.", 12, Color.LTGRAY, false))

        content.addView(button("🎮  ESTILO DOS CONTROLES") { controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(12, 8, 12, 8); setBackgroundColor(panel) }
        content.addView(controls)
        addSpinner(controls, "Layout", listOf("Xbox", "PlayStation", "Nintendo"), "controller")
        controls.addView(label("PRÉVIA DOS CONTROLES — somente visual nesta versão", 12, lime, true))
        val dpad = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.VERTICAL }
        dpad.addView(button("▲") {})
        val mid = LinearLayout(this).apply { gravity = Gravity.CENTER }
        mid.addView(button("◀") {}); mid.addView(button("●") {}); mid.addView(button("▶") {})
        dpad.addView(mid); dpad.addView(button("▼") {})
        controls.addView(dpad)
        val face = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("Y / △", "X / □", "B / ○", "A / ✕").forEach { face.addView(button(it) {}) }
        controls.addView(face)
        controls.addView(label("Os botões acima não enviam comandos ao X360 Mobile. Para controlar o jogo, use os controles integrados no próprio emulador. Não é possível sobrepor controles de outro app com este launcher comum.", 12, Color.LTGRAY, false))
        content.addView(label("Aviso: este app não contém o jogo nem um núcleo de emulação. Compatibilidade e desempenho dependem do X360 Mobile, do formato do jogo e do hardware.", 12, Color.LTGRAY, false))
        setContentView(root)
    }

    private fun chooseGame() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(i, 41) } catch (_: Exception) { status.text = "Não foi possível abrir o seletor de arquivos." }
    }

    @Deprecated("Deprecated by Android API; works for this simple document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == Activity.RESULT_OK) {
            isoUri = data?.data
            isoUri?.let { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                status.text = "Arquivo selecionado: ${uri.lastPathSegment ?: uri.toString()}"
            }
        }
    }

    private fun analyzeSelectedFile() {
        val uri = isoUri
        if (uri == null) {
            status.text = "Selecione primeiro um arquivo ISO/XISO/XEX."
            return
        }
        try {
            val name = uri.lastPathSegment ?: "arquivo selecionado"
            val size = contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
            val header = contentResolver.openInputStream(uri)?.use { input ->
                val bytes = ByteArray(4)
                val n = input.read(bytes)
                if (n == 4) bytes.joinToString("") { "%02X".format(it) } else "cabeçalho incompleto"
            } ?: "não foi possível ler"
            val type = when (header) {
                "58455832" -> "Assinatura XEX2 detectada"
                "434F4E20" -> "Cabeçalho CON detectado"
                else -> "Assinatura XEX2 não detectada no início do arquivo"
            }
            val sizeText = if (size >= 0) "${size / 1024} KiB" else "tamanho indisponível"
            val report = "Diagnóstico PES 2013 v1.3 DEV\nArquivo: $name\nTamanho: $sizeText\nPrimeiros 4 bytes: $header\nResultado: $type\n\nEste diagnóstico não valida o executável nem implementa recompilação. O motor nativo ainda não está presente."
            status.text = "$type • $sizeText"
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Diagnóstico PES 2013 Android")
                putExtra(Intent.EXTRA_TEXT, report)
            }
            startActivity(Intent.createChooser(send, "Compartilhar diagnóstico"))
        } catch (e: Exception) {
            status.text = "Falha ao analisar arquivo: ${e.message ?: "erro de leitura"}"
        }
    }

    private fun analyzeXexHeader() {
        val uri = isoUri
        if (uri == null) {
            status.text = "Selecione o default.XEX extraído — não a ISO."
            return
        }
        try {
            val report = contentResolver.openInputStream(uri)?.use { input ->
                // Read only the XEX header and optional-header table; no large game data is loaded into RAM.
                val header = input.readNBytes(24)
                if (header.size < 24) throw IllegalArgumentException("Arquivo menor que o cabeçalho XEX2 mínimo.")
                fun u32(b: ByteArray, offset: Int): Long {
                    require(offset >= 0 && offset + 4 <= b.size) { "Campo fora dos dados lidos." }
                    return ((b[offset].toLong() and 0xFF) shl 24) or
                        ((b[offset + 1].toLong() and 0xFF) shl 16) or
                        ((b[offset + 2].toLong() and 0xFF) shl 8) or
                        (b[offset + 3].toLong() and 0xFF)
                }
                val magic = String(header.copyOfRange(0, 4), Charsets.US_ASCII)
                if (magic != "XEX2") {
                    throw IllegalArgumentException("Assinatura encontrada: $magic; esperado XEX2.")
                }
                val moduleFlags = u32(header, 4)
                val peOffset = u32(header, 8)
                val reserved = u32(header, 12)
                val securityOffset = u32(header, 16)
                val declaredCount = u32(header, 20)
                if (declaredCount > 4096) throw IllegalArgumentException("Quantidade de cabeçalhos opcionais fora do limite seguro: $declaredCount.")
                val tableBytes = declaredCount.toInt() * 8
                val table = input.readNBytes(tableBytes)
                val parsedCount = table.size / 8
                val entries = (0 until parsedCount).joinToString("\n") { i ->
                    val key = u32(table, i * 8).toString(16).uppercase().padStart(8, '0')
                    val value = u32(table, i * 8 + 4).toString(16).uppercase().padStart(8, '0')
                    "• 0x$key → 0x$value"
                }
                val size = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                buildString {
                    appendLine("PES 2013 Android — relatório XEX v1.5 DEV")
                    appendLine("Arquivo: ${uri.lastPathSegment ?: "selecionado"}")
                    appendLine("Tamanho: ${if (size >= 0) "$size bytes" else "indisponível"}")
                    appendLine("Assinatura: $magic")
                    appendLine("Module flags: 0x${moduleFlags.toString(16).uppercase()}")
                    appendLine("Offset da imagem PE: 0x${peOffset.toString(16).uppercase()}")
                    appendLine("Campo reservado: 0x${reserved.toString(16).uppercase()}")
                    appendLine("Offset Security Info: 0x${securityOffset.toString(16).uppercase()}")
                    appendLine("Cabeçalhos opcionais declarados: $declaredCount")
                    appendLine("Cabeçalhos completos lidos: $parsedCount")
                    if (parsedCount > 0) appendLine("\nEntradas opcionais:\n$entries")
                    if (parsedCount < declaredCount.toInt()) appendLine("\nAVISO: tabela truncada ou leitura incompleta.")
                    appendLine("\nEste relatório verifica apenas a estrutura inicial do XEX. Não descriptografa/descomprime a imagem, não carrega código PowerPC e não executa o jogo.")
                }
            } ?: throw IllegalStateException("Não foi possível abrir o arquivo.")
            status.text = "Cabeçalho XEX2 analisado • relatório pronto"
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Relatório XEX2 — v1.5 DEV")
                putExtra(Intent.EXTRA_TEXT, report)
            }, "Compartilhar relatório XEX2"))
        } catch (e: Exception) {
            status.text = "Falha ao analisar XEX: ${e.message ?: "erro desconhecido"}"
        }
    }

    private fun launchGame() {
        val uri = isoUri
        if (uri == null) {
            status.text = "Selecione primeiro o arquivo ISO/XISO ou XEX do jogo."
            return
        }
        // X360 Mobile documents external-front-end support, but the public docs do not specify a stable launch contract.
        // Try Android ACTION_VIEW with the selected document URI, then fall back to opening the emulator app.
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage("emu.x360mobile.com")
        }
        try {
            startActivity(view)
        } catch (_: ActivityNotFoundException) {
            try {
                val launch = packageManager.getLaunchIntentForPackage("emu.x360mobile.com")
                if (launch != null) startActivity(launch)
                else status.text = "X360 Mobile não encontrado. Instale-o e importe o jogo diretamente nele."
            } catch (_: Exception) { status.text = "Não consegui abrir o X360 Mobile. Importe o jogo diretamente no emulador." }
        } catch (_: Exception) {
            try {
                val launch = packageManager.getLaunchIntentForPackage("emu.x360mobile.com")
                if (launch != null) startActivity(launch)
                else status.text = "X360 Mobile não encontrado. Instale-o e importe o jogo diretamente nele."
            } catch (_: Exception) { status.text = "Não consegui encaminhar o jogo. Abra-o diretamente no X360 Mobile." }
        }
    }

    private fun addSpinner(parent: LinearLayout, title: String, items: List<String>, key: String) {
        parent.addView(label(title, 13, Color.WHITE, true))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        val saved = prefs.getString(key, items[0])
        val idx = items.indexOf(saved).let { if (it >= 0) it else 0 }
        sp.setSelection(idx)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { prefs.edit().putString(key, items[position]).apply() }
        }
        parent.addView(sp)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(4, 8, 4, 8)
    }
    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; setTextColor(Color.BLACK); setBackgroundColor(lime); textSize = 13f
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 7, 0, 7); layoutParams = lp
        setOnClickListener { action() }
    }
}
